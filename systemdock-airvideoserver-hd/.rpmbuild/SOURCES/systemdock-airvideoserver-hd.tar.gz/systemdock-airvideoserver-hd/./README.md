= SystemDock profile for Svarog CI container

Profile to run Svarog CI container as systemd service using SystemDock (https://github.com/rpavlyuk/systemdock)

WORK IN PROGRESS
